"""
MIT License

Copyright (c) 2024 TheHamkerCat

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
"""
import random
from datetime import datetime

import pytz
from pyrogram import enums, filters

from wbb import app
from wbb.core.decorators.errors import capture_err
from wbb.utils.dbfunctions import get_couple, save_couple

__MODULE__ = "Shippering"
__HELP__ = "/detect_gay - To Choose Couple Of The Day"


# Date and time
def dt():
    # Set the timezone to Indian Standard Time
    ist_timezone = pytz.timezone("Asia/Kolkata")

    # Get the current time in IST
    ist_now = datetime.now(ist_timezone)

    dt_string = ist_now.strftime("%d/%m/%Y %H:%M")
    dt_list = dt_string.split(" ")
    return dt_list


def dt_tom():
    a = (
        str(int(dt()[0].split("/")[0]) + 1)
        + "/"
        + dt()[0].split("/")[1]
        + "/"
        + dt()[0].split("/")[2]
    )
    return a


def today():
    return str(dt()[0])


def tomorrow():
    return str(dt_tom())


@app.on_message(filters.command("detect_gay", prefixes="/!"))
@capture_err
async def couple(_, message):
    if message.chat.type == enums.ChatType.PRIVATE:
        return await message.reply_text("هذا الأمر يعمل في المجموعات فقط.")

    m = await message.reply("جارٍ الكشف...")

    try:
        chat_id = message.chat.id
        is_selected = await get_couple(chat_id, today())
        if not is_selected:
            list_of_users = []
            async for i in app.get_chat_members(message.chat.id):
                if not i.user.is_bot and not i.user.is_deleted:
                    user = await app.get_users(i.user.id)
                    list_of_users.append(user.id)
            if len(list_of_users) < 2:
                return await m.edit("لا يوجد مستخدمون كافون.")
            c1_id = random.choice(list_of_users)
            c2_id = random.choice(list_of_users)
            while c1_id == c2_id:
                c1_id = random.choice(list_of_users)
            c1_mention = (await app.get_users(c1_id)).mention
            c2_mention = (await app.get_users(c2_id)).mention

            couple_selection_message = f"""**Couple of the day:**
{c1_mention} + {c2_mention} = ❤️

__New couple of the day may be chosen at 12AM {tomorrow()}__"""
            await m.edit(couple_selection_message)
            couple = {"c1_id": c1_id, "c2_id": c2_id}
            await save_couple(chat_id, today(), couple)

        elif is_selected:
            c1_id = int(is_selected["c1_id"])
            c2_id = int(is_selected["c2_id"])
            c1_name = (await app.get_users(c1_id)).first_name
            c2_name = (await app.get_users(c2_id)).first_name
            couple_selection_message = f"""Couple of the day:
[{c1_name}](tg://openmessage?user_id={c1_id}) + [{c2_name}](tg://openmessage?user_id={c2_id}) = ❤️

__New couple of the day may be chosen at 12AM {tomorrow()}__"""
            await m.edit(couple_selection_message)
    except Exception as e:
        print(e)
        await message.reply_text(e)
